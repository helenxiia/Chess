// DO NOT MODIFY THIS FILE
#include "observer.h"

Observer::~Observer() {}
